# Oracle APEX Graph Visualization Plug-in 26.1

This directory contains an unmodified copy of Oracle's Graph Visualization
plug-in release 26.1 and its required Oracle AI Database 26ai helper scripts.

- Source release: [oracle/apex, branch 26.1](https://github.com/oracle/apex/tree/26.1/plugins/region/graph-visualization)
- Plug-in export release: `26.1.0`
- Plug-in file: `region_type_plugin_graphviz.sql`
- SHA-256: `6B07F6EBD8DB3AC30F1B37F8F528A4C8CF816DDAA46569714D7C600258F56098`

Install `gvt_sqlgraph_to_json.sql` and `required_helper_functions.sql` in the
target APEX workspace before importing `region_type_plugin_graphviz.sql` as an
APEX plug-in. Keep `THIRD_PARTY_LICENSES.txt` with the plug-in export.
