# BOM Graph Demo — Italian Edition

Release `v1.0.0` is a portable, read-only Oracle APEX demonstration of Bill of
Materials analysis with SQL Property Graph pattern matching and `DBMS_OGA` graph
algorithms. It contains Italian user-facing application text and the Graph
Visualization plug-in 26.1.

## Requirements

- Oracle AI Database 26ai, or a later release that supports SQL Property Graph
  and `DBMS_OGA`.
- Oracle APEX 26.1.
- A target APEX workspace and an application parsing schema.
- A database administrator who can grant the target schema the privileges in
  `database/sql/00-create_user.sql`, including `CREATE PROPERTY GRAPH` and
  `EXECUTE` on `DBMS_OGA`.

The target parsing schema owns the tables, SQL Property Graph, views, and
plug-in helper functions. End users do not need database accounts or database
object privileges.

## Contents

| Directory | Contents |
| --- | --- |
| `app/standard-sql/` | Single-file APEX application export for App Builder import. |
| `app/apexlang/` | Editable APEXlang source exported from the installed application. |
| `database/` | Schema, generated demo data, property graph, views, and plug-in helper installation. |
| `plugins/` | Pinned Graph Visualization plug-in 26.1 source and license information. |
| `docs/` | BOM data-model diagram. |

## Installation

1. Create or select an APEX workspace and an empty target parsing schema.

2. Arrange the required database privileges. For a dedicated `BOMUSER` schema,
   an administrator can run `database/sql/00-create_user.sql`. This script is
   optional and destructive: it drops an existing `BOMUSER` account. Do not run
   it for an existing application schema.

3. Connect as the target parsing schema and run the database installer:

   ```sql
   @database/01-install_database.sql
   ```

   The installer creates the BOM tables, generates the demo dataset, creates
   `bom_graph_apex`, creates the Graph Visualization views, and installs the
   two required helper APIs.

4. In the target workspace, open **App Builder > Import**, upload
   `app/standard-sql/f120.sql`, then select:

   - the target parsing schema;
   - an available application ID; and
   - a unique application alias, such as `BOM-GRAPH-DEMO-IT`.

   The standard application export already contains the application-scoped
   Graph Visualization plug-in definition and its static files. Do not import
   the standalone region plug-in separately for this default path.

5. Run the imported application and sign in with the target workspace's
   configured authentication scheme.

## Validation

Before importing the APEX application, verify that the database installation
completed without errors. The `02-run_all_populate_bom_demo.sql` runner performs
data and package checks. To exercise the stand-alone SQL Property Graph sample,
run `database/sql/10-create_bom_graph.sql` followed by
`database/sql/11-query_bom_graph.sql` as the target schema.

## Advanced: APEXlang source

`app/apexlang/` is provided for developers who want to review or modify the
application. Use SQLcl to validate it first, then import it with an explicit
target workspace, application ID, schema, and alias. If an APEXlang import
cannot resolve the Graph Visualization plug-in, import
`plugins/graph-visualization-plugin-26.1/region_type_plugin_graphviz.sql` first.

The helper scripts in `database/plugin-helpers/` must be installed in the
target parsing schema for either import path.

## Security and operational notes

- Do not distribute `BOMUSER` passwords or database connection strings.
- Keep the application parsing schema separate from end-user identities.
- The database installer is repeatable for the demo data, but it resets the
  BOM demo tables. Use an isolated schema rather than a production schema.
- The Graph Visualization plug-in source and third-party license notices are
  included under `plugins/graph-visualization-plugin-26.1/`.

For APEX export/import guidance, see Oracle's
[Exporting and Importing Applications](https://docs.oracle.com/en/database/oracle/apex/26.1/apxdc/exporting-and-importing-applications.html).
