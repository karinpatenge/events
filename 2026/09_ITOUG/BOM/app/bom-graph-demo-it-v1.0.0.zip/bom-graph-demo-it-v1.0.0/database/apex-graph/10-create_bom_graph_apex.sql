--==============================================================================
--  10-create_bom_graph_apex.sql
--  Last update: 2026-08-31

--  Creates the alias-free BOM_GRAPH_APEX SQL Property Graph for APEX graph
--  visualization queries.
--
--  Prerequisite:
--    * Run as BOMUSER after 01-create_schema.sql and the BOM data load scripts.
--
--  The script drops any existing BOM_GRAPH_APEX before replacing its edge views.
--  The views retain BOM_GRAPH labels, keys, relationships, and non-JSON
--  properties without table aliases for GRAPH_TABLE queries with ONE ROW PER.
--  Source: https://docs.oracle.com/en/database/oracle/property-graph/26.3/spgdg/
--    using-one-row-clause-sql-graph-query.html
--
--==============================================================================

PROMPT
PROMPT === Dropping BOM_GRAPH_APEX if it exists ===

DROP PROPERTY GRAPH IF EXISTS bom_graph_apex;

PROMPT
PROMPT === Creating BOM_GRAPH_APEX edge views ===

CREATE OR REPLACE VIEW bom_component_category_edge_v AS
SELECT
  component_id,
  part_number,
  component_name,
  category_id,
  powertrain_type,
  unit_of_measure,
  standard_cost,
  weight_kg,
  lifecycle_status,
  created_date
FROM
  bom_components;

CREATE OR REPLACE VIEW bom_component_revision_edge_v AS
SELECT
  revision_id,
  component_id,
  revision_code,
  revision_date,
  eco_number,
  engineer_name,
  change_summary,
  revision_status
FROM
  bom_component_revisions;

CREATE OR REPLACE VIEW bom_component_variant_edge_v AS
SELECT
  variant_id,
  component_id,
  variant_code,
  variant_name,
  region_code,
  market_segment,
  cost_adjustment,
  variant_status
FROM
  bom_component_variants;

CREATE OR REPLACE VIEW bom_top_component_edge_v AS
SELECT
  bom_id,
  bom_code,
  bom_name,
  vehicle_model,
  model_year,
  trim_level,
  powertrain_type,
  plant_code,
  top_component_id,
  effective_date,
  expiration_date,
  bom_status
FROM
  bom_headers;

CREATE OR REPLACE VIEW bom_item_bom_edge_v AS
SELECT
  bom_item_id,
  bom_id,
  parent_item_id,
  component_id,
  revision_id,
  variant_id,
  level_num,
  sequence_num,
  find_number,
  quantity,
  reference_designator
FROM
  bom_items;

CREATE OR REPLACE VIEW bom_item_parent_edge_v AS
SELECT
  bom_item_id,
  bom_id,
  parent_item_id,
  component_id,
  revision_id,
  variant_id,
  level_num,
  sequence_num,
  find_number,
  quantity,
  reference_designator
FROM
  bom_items;

CREATE OR REPLACE VIEW bom_item_component_edge_v AS
SELECT
  bom_item_id,
  bom_id,
  parent_item_id,
  component_id,
  revision_id,
  variant_id,
  level_num,
  sequence_num,
  find_number,
  quantity,
  reference_designator
FROM
  bom_items;

CREATE OR REPLACE VIEW bom_item_revision_edge_v AS
SELECT
  bom_item_id,
  bom_id,
  parent_item_id,
  component_id,
  revision_id,
  variant_id,
  level_num,
  sequence_num,
  find_number,
  quantity,
  reference_designator
FROM
  bom_items;

CREATE OR REPLACE VIEW bom_item_variant_edge_v AS
SELECT
  bom_item_id,
  bom_id,
  parent_item_id,
  component_id,
  revision_id,
  variant_id,
  level_num,
  sequence_num,
  find_number,
  quantity,
  reference_designator
FROM
  bom_items;

PROMPT
PROMPT === Creating BOM_GRAPH_APEX ===

CREATE OR REPLACE PROPERTY GRAPH bom_graph_apex
  VERTEX TABLES (
    bom_categories
      KEY (category_id)
      LABEL category
      PROPERTIES ARE ALL COLUMNS,
    bom_components
      KEY (component_id)
      LABEL component
      PROPERTIES ARE ALL COLUMNS EXCEPT (
        specifications
      , compliance
      ),
    bom_component_revisions
      KEY (revision_id)
      LABEL component_revision
      PROPERTIES ARE ALL COLUMNS EXCEPT (
        specifications
      ),
    bom_component_variants
      KEY (variant_id)
      LABEL component_variant
      PROPERTIES ARE ALL COLUMNS EXCEPT (
        variant_attributes
      ),
    bom_headers
      KEY (bom_id)
      LABEL bom_header
      PROPERTIES ARE ALL COLUMNS EXCEPT (
        bom_metadata
      ),
    bom_items
      KEY (bom_item_id)
      LABEL bom_item
      PROPERTIES ARE ALL COLUMNS EXCEPT (
        item_attributes
      )
  )
  EDGE TABLES (
    bom_component_category_edge_v
      KEY (component_id)
      SOURCE KEY (component_id) REFERENCES bom_components (component_id)
      DESTINATION KEY (category_id) REFERENCES bom_categories (category_id)
      LABEL component_category
      PROPERTIES ARE ALL COLUMNS,
    bom_component_revision_edge_v
      KEY (revision_id)
      SOURCE KEY (revision_id) REFERENCES bom_component_revisions (revision_id)
      DESTINATION KEY (component_id) REFERENCES bom_components (component_id)
      LABEL component_revision
      PROPERTIES ARE ALL COLUMNS,
    bom_component_variant_edge_v
      KEY (variant_id)
      SOURCE KEY (variant_id) REFERENCES bom_component_variants (variant_id)
      DESTINATION KEY (component_id) REFERENCES bom_components (component_id)
      LABEL component_variant
      PROPERTIES ARE ALL COLUMNS,
    bom_top_component_edge_v
      KEY (bom_id)
      SOURCE KEY (bom_id) REFERENCES bom_headers (bom_id)
      DESTINATION KEY (top_component_id) REFERENCES bom_components (component_id)
      LABEL bom_top_component
      PROPERTIES ARE ALL COLUMNS,
    bom_item_bom_edge_v
      KEY (bom_item_id)
      SOURCE KEY (bom_item_id) REFERENCES bom_items (bom_item_id)
      DESTINATION KEY (bom_id) REFERENCES bom_headers (bom_id)
      LABEL bom_item_bom
      PROPERTIES ARE ALL COLUMNS,
    bom_item_parent_edge_v
      KEY (bom_item_id)
      SOURCE KEY (bom_item_id) REFERENCES bom_items (bom_item_id)
      DESTINATION KEY (parent_item_id) REFERENCES bom_items (bom_item_id)
      LABEL bom_item_parent
      PROPERTIES ARE ALL COLUMNS,
    bom_item_component_edge_v
      KEY (bom_item_id)
      SOURCE KEY (bom_item_id) REFERENCES bom_items (bom_item_id)
      DESTINATION KEY (component_id) REFERENCES bom_components (component_id)
      LABEL bom_item_component
      PROPERTIES ARE ALL COLUMNS,
    bom_item_revision_edge_v
      KEY (bom_item_id)
      SOURCE KEY (bom_item_id) REFERENCES bom_items (bom_item_id)
      DESTINATION KEY (revision_id) REFERENCES bom_component_revisions (revision_id)
      LABEL bom_item_revision
      PROPERTIES ARE ALL COLUMNS,
    bom_item_variant_edge_v
      KEY (bom_item_id)
      SOURCE KEY (bom_item_id) REFERENCES bom_items (bom_item_id)
      DESTINATION KEY (variant_id) REFERENCES bom_component_variants (variant_id)
      LABEL bom_item_variant
      PROPERTIES ARE ALL COLUMNS
  )
  OPTIONS (TRUSTED MODE);

PROMPT
PROMPT === BOM_GRAPH_APEX created ===
