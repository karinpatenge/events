--==============================================================================
--  11-create_bom_graph_visualization_views.sql
--  Last update: 2026-08-31

--  Creates static SQL views for Graph Visualization plug-in regions.
--  The views evaluate GRAPH_TABLE as static SQL while retaining JSON vertex and
--  edge identifiers for the plug-in's dynamic SQL serializer.
--
--  Prerequisite:
--    * Run as BOMUSER after 10-create_bom_graph_apex.sql.
--
--==============================================================================

PROMPT
PROMPT === Creating BOM_GRAPH_APEX visualization views ===

CREATE OR REPLACE VIEW bom_graph_apex_edges_v AS
SELECT
  source_vertex_id,
  edge_id,
  destination_vertex_id
FROM
  GRAPH_TABLE (
    bom_graph_apex
    MATCH
      (source_vertex) -[edge]-> (destination_vertex)
    COLUMNS (
      VERTEX_ID(source_vertex) AS source_vertex_id,
      EDGE_ID(edge) AS edge_id,
      VERTEX_ID(destination_vertex) AS destination_vertex_id
    )
  );

CREATE OR REPLACE VIEW bom_graph_apex_hierarchy_v AS
SELECT
  bom_code,
  source_vertex_id,
  edge_id,
  destination_vertex_id
FROM
  GRAPH_TABLE (
    bom_graph_apex
    MATCH
      (header_node IS bom_header)
      <-[bom_item_bom_edge IS bom_item_bom]-
      (root_item_node IS bom_item WHERE root_item_node.parent_item_id IS NULL)
      (<-[bom_item_parent_edge IS bom_item_parent]-){,6}
      (bom_item_node IS bom_item)
      -[bom_item_component_edge IS bom_item_component]->
      (component_node IS component)
    ONE ROW PER STEP (
      step_source_node,
      step_edge,
      step_destination_node
    )
    COLUMNS (
      header_node.bom_code AS bom_code,
      VERTEX_ID(step_source_node) AS source_vertex_id,
      EDGE_ID(step_edge) AS edge_id,
      VERTEX_ID(step_destination_node) AS destination_vertex_id
    )
  );

CREATE OR REPLACE VIEW bom_graph_apex_shared_categories_v AS
WITH
  category_powertrain_usage AS (
    SELECT
      category_id,
      powertrain_type
    FROM
      GRAPH_TABLE (
        bom_graph_apex
        MATCH
          (category_node IS category)
          <-[component_category_edge IS component_category]-
          (component_node IS component)
          <-[bom_item_component_edge IS bom_item_component]-
          (bom_item_node IS bom_item)
          -[bom_item_bom_edge IS bom_item_bom]->
          (header_node IS bom_header)
        COLUMNS (
          category_node.category_id AS category_id,
          header_node.powertrain_type AS powertrain_type
        )
      )
    GROUP BY
      category_id,
      powertrain_type
  ),
  shared_category AS (
    SELECT
      category_id
    FROM
      category_powertrain_usage
    WHERE
      powertrain_type IN (
        'ICE',
        'EV'
      )
    GROUP BY
      category_id
    HAVING
      COUNT(DISTINCT powertrain_type) = 2
  )
SELECT
  graph_result.source_vertex_id,
  graph_result.edge_id,
  graph_result.destination_vertex_id
FROM
  GRAPH_TABLE (
    bom_graph_apex
    MATCH
      (category_node IS category)
      <-[component_category_edge IS component_category]-
      (component_node IS component)
      <-[bom_item_component_edge IS bom_item_component]-
      (bom_item_node IS bom_item)
      -[bom_item_bom_edge IS bom_item_bom]->
      (header_node IS bom_header WHERE header_node.powertrain_type IN (
        'ICE',
        'EV'
      ))
    ONE ROW PER STEP (
      step_source_node,
      step_edge,
      step_destination_node
    )
    COLUMNS (
      category_node.category_id AS category_id,
      VERTEX_ID(step_source_node) AS source_vertex_id,
      EDGE_ID(step_edge) AS edge_id,
      VERTEX_ID(step_destination_node) AS destination_vertex_id
    )
  ) graph_result
  JOIN shared_category
    ON shared_category.category_id = graph_result.category_id;

CREATE OR REPLACE VIEW bom_graph_apex_lifecycle_risk_v AS
SELECT
  source_vertex_id,
  edge_id,
  destination_vertex_id
FROM
  GRAPH_TABLE (
    bom_graph_apex
    MATCH
      (header_node IS bom_header)
      <-[bom_item_bom_edge IS bom_item_bom]-
      (bom_item_node IS bom_item)
      -[bom_item_component_edge IS bom_item_component]->
      (component_node IS component WHERE component_node.lifecycle_status <> 'ACTIVE')
    ONE ROW PER STEP (
      step_source_node,
      step_edge,
      step_destination_node
    )
    COLUMNS (
      VERTEX_ID(step_source_node) AS source_vertex_id,
      EDGE_ID(step_edge) AS edge_id,
      VERTEX_ID(step_destination_node) AS destination_vertex_id
    )
  )
UNION ALL
SELECT
  source_vertex_id,
  edge_id,
  destination_vertex_id
FROM
  GRAPH_TABLE (
    bom_graph_apex
    MATCH
      (header_node IS bom_header)
      <-[bom_item_bom_edge IS bom_item_bom]-
      (bom_item_node IS bom_item)
      -[bom_item_variant_edge IS bom_item_variant]->
      (variant_node IS component_variant WHERE variant_node.variant_status <> 'ACTIVE')
    ONE ROW PER STEP (
      step_source_node,
      step_edge,
      step_destination_node
    )
    COLUMNS (
      VERTEX_ID(step_source_node) AS source_vertex_id,
      EDGE_ID(step_edge) AS edge_id,
      VERTEX_ID(step_destination_node) AS destination_vertex_id
    )
  );

CREATE OR REPLACE VIEW bom_graph_apex_revision_impact_v AS
SELECT
  revision_id,
  source_vertex_id,
  edge_id,
  destination_vertex_id
FROM
  GRAPH_TABLE (
    bom_graph_apex
    MATCH
      affected_bom_path = (selected_revision_node IS component_revision)
      <-[selected_bom_item_revision_edge IS bom_item_revision]-
      (selected_bom_item_node IS bom_item)
      -[selected_bom_item_bom_edge IS bom_item_bom]->
      (header_node IS bom_header),
      other_revision_path = (selected_revision_node IS component_revision)
      -[selected_component_revision_edge IS component_revision]->
      (component_node IS component)
      <-[other_component_revision_edge IS component_revision]-
      (other_revision_node IS component_revision)
    WHERE
      NOT VERTEX_EQUAL(selected_revision_node, other_revision_node)
    ONE ROW PER STEP (
      step_source_node,
      step_edge,
      step_destination_node
    )
    IN (
      affected_bom_path,
      other_revision_path
    )
    COLUMNS (
      selected_revision_node.revision_id AS revision_id,
      VERTEX_ID(step_source_node) AS source_vertex_id,
      EDGE_ID(step_edge) AS edge_id,
      VERTEX_ID(step_destination_node) AS destination_vertex_id
    )
  );

CREATE OR REPLACE VIEW bom_graph_apex_pagerank_v AS
WITH
  component_ranks AS (
    SELECT
      component_id,
      component_pagerank
    FROM
      GRAPH_TABLE (
        DBMS_OGA.PAGERANK (
          bom_graph_apex,
          PROPERTY(VERTEX OUTPUT component_pagerank),
          50,
          0.000001d,
          0.85d,
          FALSE
        )
        MATCH (component_node IS component)
        COLUMNS (
          component_node.component_id AS component_id,
          component_node.component_pagerank AS component_pagerank
        )
      )
  ),
  top_components AS (
    SELECT
      component_id
    FROM
      component_ranks
    ORDER BY
      component_pagerank DESC,
      component_id
    FETCH FIRST 20 ROWS ONLY
  )
SELECT
  graph_result.source_vertex_id,
  graph_result.edge_id,
  graph_result.destination_vertex_id
FROM
  GRAPH_TABLE (
    bom_graph_apex
    MATCH
      (header_node IS bom_header)
      <-[bom_item_bom_edge IS bom_item_bom]-
      (bom_item_node IS bom_item)
      -[bom_item_component_edge IS bom_item_component]->
      (component_node IS component)
    ONE ROW PER STEP (
      step_source_node,
      step_edge,
      step_destination_node
    )
    COLUMNS (
      component_node.component_id AS component_id,
      VERTEX_ID(step_source_node) AS source_vertex_id,
      EDGE_ID(step_edge) AS edge_id,
      VERTEX_ID(step_destination_node) AS destination_vertex_id
    )
  ) graph_result
  JOIN top_components
    ON top_components.component_id = graph_result.component_id;

PROMPT
PROMPT === BOM_GRAPH_APEX visualization views created ===
