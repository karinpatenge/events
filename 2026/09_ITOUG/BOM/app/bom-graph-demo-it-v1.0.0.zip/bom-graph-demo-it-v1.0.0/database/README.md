# Database installation

Run `01-install_database.sql` as the target APEX parsing schema after the
required database privileges have been granted. It does not create a user and
does not grant privileges.

The optional `sql/00-create_user.sql` is for a new dedicated `BOMUSER` schema
only. It prompts securely for a password, but it also drops an existing
`BOMUSER` account before recreating it.

The default installer intentionally creates only `bom_graph_apex`, which is the
alias-free SQL Property Graph required by the APEX Graph Visualization regions.
The stand-alone `sql/10-create_bom_graph.sql` and
`sql/11-query_bom_graph.sql` scripts remain available for SQL/PGQ exploration.
