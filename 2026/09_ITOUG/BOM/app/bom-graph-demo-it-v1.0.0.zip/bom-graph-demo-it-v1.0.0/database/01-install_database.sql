--==============================================================================
--  01-install_database.sql
--  Last update: 2026-09-16

--  Creates the database objects required by the BOM Graph Demo Italian APEX
--  application in the current target parsing schema.
--
--  Prerequisite:
--    * Run as the target application parsing schema after the required
--      SQL Property Graph and DBMS_OGA privileges have been granted.
--==============================================================================

SET ECHO ON
SET FEEDBACK ON
SET SERVEROUTPUT ON SIZE UNLIMITED
SET LINESIZE 220
SET PAGESIZE 200
SET DEFINE OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE

PROMPT
PROMPT === Creating BOM database objects and demo data ===

@@sql/01-create_schema.sql
@@sql/02-run_all_populate_bom_demo.sql

PROMPT
PROMPT === Creating the APEX SQL Property Graph ===

@@apex-graph/10-create_bom_graph_apex.sql
@@apex-graph/11-create_bom_graph_visualization_views.sql

PROMPT
PROMPT === Installing Graph Visualization helper APIs ===

@@plugin-helpers/gvt_sqlgraph_to_json.sql
@@plugin-helpers/required_helper_functions.sql

PROMPT
PROMPT === BOM Graph Demo database installation complete ===
