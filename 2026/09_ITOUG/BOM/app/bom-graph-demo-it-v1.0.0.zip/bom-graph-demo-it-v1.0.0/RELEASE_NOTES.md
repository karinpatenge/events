# Release notes — v1.0.0

## Application

- Name: `Demo del grafo BOM`
- Source application ID: `120`
- Source alias: `BOM-GRAPH-DEMO-IT`
- Source workspace: `ITOUG2026`
- Language: Italian
- APEX version: 26.1

## Included capabilities

- SQL/PGQ `GRAPH_TABLE` pattern-matching pages for BOM schema, component usage,
  BOM hierarchy, shared categories, lifecycle/revision impact, and BOM/revision
  discovery.
- `DBMS_OGA` PageRank and weakly connected components demonstrations.
- Graph Visualization plug-in 26.1, application-scoped in the standard export.
- Database bootstrap scripts that generate the complete demo dataset and the
  alias-free `bom_graph_apex` required by Graph Visualization regions.

## Intentional installation boundaries

- The release does not create or import APEX users, workspace users, passwords,
  saved reports, or application access-control assignments.
- `database/sql/00-create_user.sql` is supplied only for a new, dedicated
  `BOMUSER` schema. It is not called by `database/01-install_database.sql`.
- The target installer must select an available application ID and unique alias.

## Integrity

See `CHECKSUMS.sha256` to verify the extracted release contents.
