# Application artifacts

Use `standard-sql/f120.sql` for the normal App Builder import path. It is a
single-file SQL export of the live Italian application and includes the
application-scoped Graph Visualization plug-in and static files.

`apexlang/` contains the corresponding editable APEXlang source. It is intended
for advanced SQLcl-based validation and import workflows, not as a replacement
for the standard import file.

Choose a new application ID and alias in every target workspace. Do not import
the release back into application ID 120 unless intentionally updating that
specific source application.
